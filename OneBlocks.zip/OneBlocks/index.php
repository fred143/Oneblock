<?php
?>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="navifooter.css">
<style>

</style>
</head>
<body>

<div class="navbar">
 <a class="logo" href="#"><img src="web.jpg" height=60 width=55 alt="img">
        </a>
   <div class="dropdown1">
    <button class="dropbtn1">SCOUT 
      <!--<i class="fa fa-caret-down"></i>-->
    </button>
    <div class="dropdown-content1">
      <a class="dropc" href="#"><img src="isobook.jpg" height=30 width=35 alt="img">
        <lable for="book"><br>BOOKS</lable>
        </a>
      <a class="dropc1" href="#"><img src="podcast.png" height=30 width=35 alt="img">
        <lable for="book"><br>PODCAST</lable>
        </a>
      <a class="dropc2" href="#"><img src="movie.png" height=30 width=35 alt="img">
        <lable for="book"><br>MOVIES</lable>
        </a>
        <a class="dropc3" href="#"><img src="tag.png" height=30 width=35 alt="img">
        <lable for="book"><br>TAG</lable>
        </a>
      <a class="dropc4" href="#"><img src="guide.png" height=30 width=35 alt="img">
        <lable for="book"><br>GUIDES</lable>
        </a>
       <a class="dropc5" href="#"><img src="webs.png" height=30 width=35 alt="img">
        <lable for="book"><br>WEBSITES</lable>
        </a>
    </div>
    </div>
  <div class="dropdown2">
    <button class="dropbtn2">COURSES 
      <!--<i class="fa fa-caret-down"></i>-->
    </button>
    <div class="dropdown-content2">
    <a class="d0" href="#"><img src="lean.jpg" height=30 width=35 alt="img">
        <lable for="book"><br>LERAN</lable>
        </a>
      <a class="d1" href="#"><img src="tut.png" height=30 width=35 alt="img">
        <lable for="book"><br>TUTORIAL</lable>
        </a>
      <a class="d2" href="#"><img src="vid.png" height=30 width=35 alt="img">
        <lable for="book"><br>VIDEOS</lable>
        </a>
        <a class="d3" href="#"><img src="chal.png" height=30 width=35 alt="img">
        <lable for="book"><br>CHALLENGES</lable>
        </a>
    </div>
    </div>
  <div class="dropdown3">
    <button class="dropbtn3">DEVELOP 
      <!--<i class="fa fa-caret-down"></i>-->
    </button>
    <div class="dropdown-content3">
     <a class="dop0" href="#"><img src="mo.jpg" height=30 width=39 alt="img">
        <lable for="book"><br>EARN</lable>
        </a>
      <a class="dop1" href="#"><img src="g.png" height=30 width=35 alt="img">
        <lable for="book"><br>GRANT</lable>
        </a>
      <a class="dop2" href="#"><img src="cont.png" height=30 width=35 alt="img">
        <lable for="book"><br>CONTRIBUTE</lable>
        </a>
        <a class="dop3" href="#"><img src="temp.jpg" height=30 width=35 alt="img">
        <lable for="book"><br>TEMPLATES </lable>
        </a>
      <a class="dop4" href="#"><img src="job.png" height=30 width=38 alt="img">
        <lable for="book"><br>JOB</lable>
        </a>
    </div>
  </div> 
         <a class="logo2" href="#"><img style="background-color:white;" src="ser.png" height=30 width=35 alt="img">
        </a>
</div>
<div class="intro">
      <div class="hydro">
       <p><span class="green" >OneBlock &nbsp;&nbsp;is a platform  for developers to explore and learn about OneBlock. Whether youre a new dev getting your hands dirty for the first time,</span>
           <span>or a seasoned developer making the transition into the OneBlock space.</span></p>

      </div>
      <div class="labe">
           <label><h1>ONEBLOCK</h1></label>
         
       <span>Browse all jobs to find your Web3, Solidity or blockchain job at one of the leading companies in the space.</span>
      </div><br>
      <div class="console">
      <button class="bt0">Engineering</button>
      <button class="bt1">Smart Contract</button>
      <button class="bt2">Full-stack</button>
      <button class="bt3">Back-end</button>
      <button class="bt4">Front-end</button>
       <button class="bt5">DevRel</button>
      <button class="bt6">Product</button>
      <button class="bt7">Design</button>   
</div>
         <div class="book">
            <label>BOOKS&nbsp;</label><a class="view" href="#">View All</a>
             <div class="data">
                  <span class="data1"><span>Another Fuck</span></span>
                   <span class="data2">Goofs</span>
                  <span class="data3">Goofs2</span>
                  <!--<span class="data4">Goofs1</span>-->
                </div>
             </div>
</div>
<div id="demo"></div>

<script>
let text =
"<p>innerWidth: " + window.innerWidth + "</p>" +
"<p>innerHeight: " + window.innerHeight + "</p>" +
"<p>outerWidth: " + window.outerWidth + "</p>" +
"<p>outerHeight: " + window.outerHeight + "</p>";

//document.getElementById("demo").innerHTML = text;
</script>


</body>
</html>